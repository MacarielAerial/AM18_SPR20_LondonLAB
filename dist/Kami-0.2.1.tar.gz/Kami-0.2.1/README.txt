# AM18_SPR20_LondonLAB

The package contains two functions: Preprocess and Analyse.

Preprocess has two arguments: 1. Path to the grouped product sales input data
			      2. Path to an intermediary folder to store intermediary data

Analyse has two arguments as well: 1. Path to an output folder to store final output
				   2. Path to the intermediary folder specified during Preprocess

To obtain final results, call Preprocess and Analyse sequentially with their respective arguments after setting up the intermediary and the output folder
